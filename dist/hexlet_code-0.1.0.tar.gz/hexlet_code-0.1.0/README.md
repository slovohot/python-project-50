### Hexlet tests and linter status:
[![Actions Status](https://github.com/slovohot/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/slovohot/python-project-50/actions)

version: python 3.11 poetry 1.4

install: для установки введите команду: make full-install

Описание проекта: Вычислитель отличий – программа, которая определяет разницу между двумя структурами данных

gendiff -h:

[![asciicast](https://asciinema.org/a/sNpAxv8aI7Kq1ZhZtskzMk4sx.svg)](https://asciinema.org/a/sNpAxv8aI7Kq1ZhZtskzMk4sx)



gendiff file1.json file2.json:

[![asciicast](https://asciinema.org/a/ANhVgLqCIjh4IKOYGtqZpkJVV.svg)](https://asciinema.org/a/ANhVgLqCIjh4IKOYGtqZpkJVV)
